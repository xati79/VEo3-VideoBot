# VEo3 VideoBot

This project auto-generates fairy tale videos using AI, voice synthesis, and video editing tools, and uploads them to YouTube.

## Structure

- frontend/: React-based interface for managing video creation
- backend/: Node.js backend integrated with Supabase
- scripts/: Automation scripts using ElevenLabs, Runway, YouTube API
- assets/: Thumbnails, subtitles, audio files

## Usage

1. Install dependencies for each folder (npm install).
2. Set up your API keys in backend/config.js.
3. Run scripts to generate and upload videos.

Enjoy automation!
